from os import getenv

from dotenv import load_dotenv

load_dotenv()

API_ID = "20193542"
# -------------------------------------------------------------
API_HASH = "b313a36f1c3b9f5b2d1b8994e7101cf6"
# --------------------------------------------------------------
BOT_TOKEN = getenv("7149692179:AAHgXhTskWZYYrICir3MWVY9rY-kG_78QZE", None)
MONGO_URL = getenv("mongodb+srv://black786:black123@cluster0.hoxbwfe.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0", None)
OWNER_ID = "6261688047"
SUPPORT_GRP = "@NKD_Korean_Group"
UPDATE_CHNL = "@NKD_Korean_Drama_Hindi"
OWNER_USERNAME = "@YTFARMAN"

